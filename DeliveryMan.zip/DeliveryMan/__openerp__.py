{
    'name':'Delivery2',
    'version':'1.1',
    'author':'ITI'
    ,'category':'point of sale',
    'website':'iti.odoo.com',
    'depends': ['point_of_sale'],
    'data': ['views.xml','delivery.xml'],
    'installable':True

}



