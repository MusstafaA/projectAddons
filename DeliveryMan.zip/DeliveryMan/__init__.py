import delivery
import sys
sys.path.insert(0, '/home/omnia/erp/addons/point_of_sale/wizard/')
sys.path.insert(0, '/home/omnia/erp/addons/point_of_sale/point_of_sale')